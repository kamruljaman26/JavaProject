/**
 * ArraySorters are objects that provide a sort method that will sort arrays of {@link java.lang.Comparable}s.
 *
 * @author Hugh Osborne
 * @version October 2019
 */
package arraySorter;